完整使用教程请查看https://github.com/Semporia/TikTok-Unlock

本套规则在Semporia规则基础上做了增加，欺骗效果更好，自测无视更新。

<PRE>
sgmodule文件适用于Surge,Shadowrocket
conf&nbsp;&nbsp;&nbsp;&#9;文件适用于圈X
plugin&nbsp;&#9;文件适用于Loon
</PRE>
